package com.example.e_survey;

public class BundleKeys {
    public static String KEY_PROFIL="profil";
}
