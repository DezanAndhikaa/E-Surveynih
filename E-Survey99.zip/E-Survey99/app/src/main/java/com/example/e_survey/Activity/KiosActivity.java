package com.example.e_survey.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.e_survey.R;

public class KiosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_kios);
    }
}
