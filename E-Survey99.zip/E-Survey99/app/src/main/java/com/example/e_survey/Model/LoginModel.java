package com.example.e_survey.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LoginModel {
//    private int id_fascam;
    private String jenis_user;
    private String username;
    private String password;
    private String nama;
    private int created_at;
    private int updated_at;
//    private int kode_qr;
//    private String kabupaten;
//    private String kecamatan;
//    private String desa;
//    private String nama_kios;

//    public int getId_fascam() {
//        return id_fascam;
//    }
//
//    public void setId_fascam(int id_fascam) {
//        this.id_fascam = id_fascam;
//    }

    public String getJenis_user() {
        return jenis_user;
    }

    public void setJenis_user(String jenis_user) {
        this.jenis_user = jenis_user;
    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }
    public int getCreated_at() {
        return created_at;
    }

    public void setCreated_at(int created_at) {
        this.created_at = created_at;
    }

    public int getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(int updated_at) {
        this.updated_at = updated_at;
    }

//    public int getKode_qr() {
//        return kode_qr;
//    }
//
//    public void setKode_qr(int kode_qr) {
//        this.kode_qr = kode_qr;
//    }
//
//    public String getKabupaten() {
//        return kabupaten;
//    }
//
//    public void setKabupaten(String kabupaten) {
//        this.kabupaten = kabupaten;
//    }
//
//    public String getKecamatan() {
//        return kecamatan;
//    }
//
//    public void setKecamatan(String kecamatan) {
//        this.kecamatan = kecamatan;
//    }
//
//    public String getDesa() {
//        return desa;
//    }
//
//    public void setDesa(String desa) {
//        this.desa = desa;
//    }
//
//    public String getNama_kios() {
//        return nama_kios;
//    }
//
//    public void setNama_kios(String nama_kios) {
//        this.nama_kios = nama_kios;
//    }
}
//    @SerializedName("status")
//    @Expose
//    private Boolean status;
//    @SerializedName("message")
//    @Expose
//    private String message;
//    @SerializedName("level")
//    @Expose
//    private String level;
//    @SerializedName("auth")
//    @Expose
//    private Auth auth;
//
//    public Boolean getStatus() {
//        return status;
//    }
//
//    public void setStatus(Boolean status) {
//        this.status = status;
//    }
//
//    public String getMessage() {
//        return message;
//    }
//
//    public void setMessage(String message) {
//        this.message = message;
//    }
//
//    public String getLevel() {
//        return level;
//    }
//
//    public void setLevel(String level) {
//        this.level = level;
//    }
//
//    public Auth getAuth() {
//        return auth;
//    }
//
//    public void setAuth(Auth auth) {
//        this.auth = auth;
//    }
//}
