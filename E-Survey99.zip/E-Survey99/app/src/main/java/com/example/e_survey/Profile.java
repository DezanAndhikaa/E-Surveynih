package com.example.e_survey;

public class Profile {
    static String idPetani;
    static String namaPetani;
    static String alamat;
    static String hp;
    static String desa;
    static String luasLahan;
    static String statusLahan;
    static String namaKelompokTani;
    static String komoditas;


    public static String getIdPetani() {
        return idPetani;
    }

    public static void setIdPetani(String idPetani) {
        Profile.idPetani = idPetani;
    }

    public static String getNamaPetani() {
        return namaPetani;
    }

    public static void setNamaPetani(String namaPetani) {
        Profile.namaPetani = namaPetani;
    }

    public static String getAlamat() {
        return alamat;
    }

    public static void setAlamat(String alamat) {
        Profile.alamat = alamat;
    }

    public static String getHp() {
        return hp;
    }

    public static void setHp(String hp) {
        Profile.hp = hp;
    }

    public static String getDesa() {
        return desa;
    }

    public static void setDesa(String desa) {
        Profile.desa = desa;
    }

    public static String getLuasLahan() {
        return luasLahan;
    }

    public static void setLuasLahan(String luasLahan) {
        Profile.luasLahan = luasLahan;
    }

    public static String getStatusLahan() {
        return statusLahan;
    }

    public static void setStatusLahan(String statusLahan) {
        Profile.statusLahan = statusLahan;
    }

    public static String getNamaKelompokTani() {
        return namaKelompokTani;
    }

    public static void setNamaKelompokTani(String namaKelompokTani) {
        Profile.namaKelompokTani = namaKelompokTani;
    }

    public static String getKomoditas() {
        return komoditas;
    }

    public static void setKomoditas(String komoditas) {
        Profile.komoditas = komoditas;
    }

}
