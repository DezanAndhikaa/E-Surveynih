package com.example.e_survey.Activity;

import android.app.Activity;

public class KuesionerTipeCbActivity extends Activity {
}
