package com.example.e_survey.Activity;

public class Soal {
    public static int parameter;
    public static String soal;
}
