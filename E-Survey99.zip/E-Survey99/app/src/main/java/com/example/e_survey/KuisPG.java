package com.example.e_survey;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class KuisPG extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_kuis_pg);
    }
}
