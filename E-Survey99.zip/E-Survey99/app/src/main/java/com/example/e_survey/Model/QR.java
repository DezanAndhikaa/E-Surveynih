package com.example.e_survey.Model;

import org.json.JSONArray;

public class QR {

    public static JSONArray jsonArray;

    public static String hasilQR;

}
