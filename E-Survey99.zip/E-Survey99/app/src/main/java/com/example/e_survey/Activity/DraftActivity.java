package com.example.e_survey.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.e_survey.R;

public class DraftActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draft);
    }
}
