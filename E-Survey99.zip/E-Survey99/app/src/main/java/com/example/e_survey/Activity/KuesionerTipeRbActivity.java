package com.example.e_survey.Activity;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.e_survey.R;

public class KuesionerTipeRbActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_list_kuesioner);
        TextView textPertanyaan = (TextView) findViewById(R.id.tvPertanyaan2);
//        textPertanyaan.setText(getIntent().getStringExtra("soal"));
    }





}