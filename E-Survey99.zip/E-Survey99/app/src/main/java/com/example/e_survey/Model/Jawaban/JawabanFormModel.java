package com.example.e_survey.Model.Jawaban;

public class JawabanFormModel {
    public String username;
    public String id_desa;
    public String id_kecamatan;
    public String id_kuisioner;
    public String id_kios;
    public String jawaban;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getId_desa() {
        return id_desa;
    }

    public void setId_desa(String id_desa) {
        this.id_desa = id_desa;
    }

    public String getId_kecamatan() {
        return id_kecamatan;
    }

    public void setId_kecamatan(String id_kecamatan) {
        this.id_kecamatan = id_kecamatan;
    }

    public String getId_kuisioner() {
        return id_kuisioner;
    }

    public void setId_kuisioner(String id_kuisioner) {
        this.id_kuisioner = id_kuisioner;
    }

    public String getId_kios() {
        return id_kios;
    }

    public void setId_kios(String id_kios) {
        this.id_kios = id_kios;
    }

    public String getJawaban() {
        return jawaban;
    }

    public void setJawaban(String jawaban) {
        this.jawaban = jawaban;
    }
}
