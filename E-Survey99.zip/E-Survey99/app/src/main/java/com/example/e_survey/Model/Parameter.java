package com.example.e_survey.Model;

public class Parameter {

}
